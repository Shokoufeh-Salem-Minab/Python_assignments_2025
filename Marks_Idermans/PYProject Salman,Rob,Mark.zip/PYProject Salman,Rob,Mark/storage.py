from auth import load_data, save_data
from security import cipher

def add_entry(site, username, password):
    data = load_data()
    encrypted_pwd = cipher.encrypt(password.encode()).decode()
    data["passwords"][site] = {
        "username": username,
        "password": encrypted_pwd
    }
    save_data(data)

def delete_entry(site):
    data = load_data()
    if site in data["passwords"]:
        del data["passwords"][site]
        save_data(data)

def get_entries():
    return load_data()["passwords"]

def get_entries_decrypted():
    entries = load_data()["passwords"]
    decrypted_entries = {}
    for site, info in entries.items():
        decrypted_entries[site] = {
            "username": info["username"],
            "password": cipher.decrypt(info["password"].encode()).decode()
        }
    return decrypted_entries
