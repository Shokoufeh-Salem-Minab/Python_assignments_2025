import tkinter as tk
from tkinter import messagebox
import random
import string

from auth import master_exists, set_master_password, verify_master_password
from storage import add_entry, delete_entry, get_entries_decrypted


class PasswordManagerGUI:
    def __init__(self):
        self.dark_mode = False

        self.root = tk.Tk()
        self.root.title("Password Manager")
        self.root.geometry("900x650")

        self.apply_theme()
        self.login_screen()

    # ---------- THEME SYSTEM ----------
    def apply_theme(self):
        if self.dark_mode:
            self.bg = "#1e1e1e"
            self.fg = "#ffffff"
            self.btn = "#2d2d2d"
            self.entry_bg = "#3a3a3a"
        else:
            self.bg = "#f4f6f8"
            self.fg = "#000000"
            self.btn = "#dddddd"
            self.entry_bg = "#ffffff"

        self.root.configure(bg=self.bg)

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.apply_theme()
        self.main_menu()

    # ---------- HELPERS ----------
    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def label(self, parent, text, size=12, bold=False):
        return tk.Label(
            parent,
            text=text,
            bg=self.bg,
            fg=self.fg,
            font=("Arial", size, "bold" if bold else "normal")
        )

    def button(self, parent, text, command, width=25):
        return tk.Button(
            parent,
            text=text,
            command=command,
            width=width,
            bg=self.btn,
            fg=self.fg,
            activebackground=self.bg
        )

    def entry(self, parent, show=None, width=40):
        return tk.Entry(
            parent,
            show=show,
            width=width,
            bg=self.entry_bg,
            fg=self.fg,
            insertbackground=self.fg
        )

    # ---------- CORE ----------
    def run(self):
        self.root.mainloop()

    # ---------- LOGIN ----------
    def login_screen(self):
        self.clear()

        frame = tk.Frame(self.root, bg=self.bg)
        frame.pack(expand=True)

        self.label(frame, "Password Manager", 26, True).pack(pady=20)
        self.label(frame, "Master Password", 14).pack()

        self.master_entry = self.entry(frame, show="*", width=30)
        self.master_entry.pack(pady=10)

        if not master_exists():
            self.button(frame, "Create Master Password", self.create_master).pack(pady=10)
        else:
            self.button(frame, "Login", self.login).pack(pady=10)

    def create_master(self):
        pwd = self.master_entry.get()
        if not pwd:
            messagebox.showerror("Error", "Password cannot be empty")
            return

        set_master_password(pwd)
        self.main_menu()

    def login(self):
        if verify_master_password(self.master_entry.get()):
            self.main_menu()
        else:
            messagebox.showerror("Error", "Incorrect password")

    # ---------- MAIN MENU ----------
    def main_menu(self):
        self.clear()

        self.label(self.root, "Password Manager", 24, True).pack(pady=20)

        self.button(self.root, "Add Password", self.add_screen).pack(pady=10)
        self.button(self.root, "View Passwords", self.view_screen).pack(pady=10)
        self.button(self.root, "Toggle Dark Mode", self.toggle_theme).pack(pady=5)
        self.button(self.root, "Logout", self.login_screen).pack(pady=5)

    # ---------- PASSWORD GENERATOR ----------
    def generate_password(self, length):
        chars = string.ascii_letters + string.digits + string.punctuation
        return "".join(random.choice(chars) for _ in range(length))

    # ---------- ADD PASSWORD ----------
    def add_screen(self):
        self.clear()

        frame = tk.Frame(self.root, bg=self.bg)
        frame.pack(expand=True)

        self.label(frame, "Add New Password", 20, True).pack(pady=20)

        self.label(frame, "Website / App").pack()
        site = self.entry(frame)
        site.pack(pady=5)

        self.label(frame, "Username").pack()
        user = self.entry(frame)
        user.pack(pady=5)

        self.label(frame, "Password").pack()
        pwd = self.entry(frame, show="*")
        pwd.pack(pady=5)

        self.label(frame, "Password Length (8–32)").pack(pady=5)
        length_entry = self.entry(frame, width=10)
        length_entry.insert(0, "16")
        length_entry.pack()

        def toggle_show():
            pwd.config(show="" if pwd.cget("show") == "*" else "*")

        def generate():
            try:
                length = int(length_entry.get())
                if length < 8 or length > 32:
                    raise ValueError
                pwd.delete(0, tk.END)
                pwd.insert(0, self.generate_password(length))
            except ValueError:
                messagebox.showerror("Error", "Password length must be between 8 and 32")

        self.button(frame, "Show / Hide Password", toggle_show, 30).pack(pady=3)
        self.button(frame, "Generate Strong Password", generate, 30).pack(pady=5)

        def save():
            add_entry(site.get(), user.get(), pwd.get())
            messagebox.showinfo("Saved", "Password stored")
            self.main_menu()

        self.button(frame, "Save", save).pack(pady=10)
        self.button(frame, "Back", self.main_menu).pack()

    # ---------- VIEW PASSWORDS ----------
    def view_screen(self):
        self.clear()

        self.label(self.root, "Saved Passwords", 20, True).pack(pady=10)

        # Search entry
        search = self.entry(self.root)
        search.pack(pady=5)

        #Container for password entries
        container = tk.Frame(self.root, bg=self.bg)
        container.pack(fill="both", expand=True)

        def refresh(*args):
            for w in container.winfo_children():
                w.destroy()

            term = search.get().lower().strip()
            entries = get_entries_decrypted()  #Decrypted passwords
            if not entries:
                self.label(container, "No passwords saved.", 14).pack(pady=20)
                return

            for site, info in entries.items():
                if term in site.lower():
                    box = tk.Frame(container, bg=self.bg, bd=1, relief="solid", padx=10, pady=10)
                    box.pack(pady=5, padx=20, fill="x")

                    self.label(box, f"Site: {site}", 12, True).pack(anchor="w")
                    self.label(box, f"Username: {info['username']}").pack(anchor="w")
                    self.label(box, f"Password: {info['password']}").pack(anchor="w")

                    self.button(box, "Delete", lambda s=site: self.delete_and_refresh(s), 10).pack(anchor="e", pady=5)

        search.bind("<KeyRelease>", refresh)
        refresh()

        self.button(self.root, "Back", self.main_menu).pack(pady=10)

    def delete_and_refresh(self, site):
        delete_entry(site)
        self.view_screen()
