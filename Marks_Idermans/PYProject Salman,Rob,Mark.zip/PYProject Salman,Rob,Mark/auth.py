import json
import os
from security import hash_password

AUTH_FILE = "data.json"


def load_data():
    if not os.path.exists(AUTH_FILE):
        return {"master": None, "passwords": {}}

    try:
        with open(AUTH_FILE, "r") as f:
            data = json.load(f)
    except json.JSONDecodeError:
        return {"master": None, "passwords": {}}

    data.setdefault("master", None)
    data.setdefault("passwords", {})
    return data


def save_data(data):
    with open(AUTH_FILE, "w") as f:
        json.dump(data, f, indent=4)


def set_master_password(password):
    data = load_data()
    data["master"] = hash_password(password)
    save_data(data)


def verify_master_password(password):
    data = load_data()
    if data["master"] is None:
        return False
    return data["master"] == hash_password(password)


def master_exists():
    data = load_data()
    return data["master"] is not None
