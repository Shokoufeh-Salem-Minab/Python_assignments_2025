from cryptography.fernet import Fernet


KEY_FILE = "secret.key"

def load_key():
    try:
        with open(KEY_FILE, "rb") as f:
            key = f.read()
    except FileNotFoundError:
        key = Fernet.generate_key()
        with open(KEY_FILE, "wb") as f:
            f.write(key)
    return key

key = load_key()
cipher = Fernet(key)


import hashlib
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()
