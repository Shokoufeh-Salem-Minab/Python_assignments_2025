from gui import PasswordManagerGUI


if __name__ == "__main__":
    app = PasswordManagerGUI()
    app.run()